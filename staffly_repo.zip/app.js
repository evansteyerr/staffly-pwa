// App logic for Staffly PWA (demo)
document.addEventListener('DOMContentLoaded', () => {
  // Update footer year
  const yy = document.getElementById('yy');
  if (yy) yy.textContent = new Date().getFullYear().toString();

  // Hamburger menu toggle
  const menuBtn = document.getElementById('menuBtn');
  const navLinks = document.getElementById('navLinks');
  if (menuBtn && navLinks) {
    menuBtn.addEventListener('click', () => {
      navLinks.classList.toggle('open');
    });
    navLinks.querySelectorAll('a').forEach(link => {
      link.addEventListener('click', () => {
        navLinks.classList.remove('open');
      });
    });
  }

  // Tabs switching between restaurant and worker forms
  const tabs = document.querySelectorAll('.tab');
  const formResto = document.getElementById('formResto');
  const formWorker = document.getElementById('formWorker');
  tabs.forEach(tab => {
    tab.addEventListener('click', () => {
      tabs.forEach(t => t.classList.remove('active'));
      tab.classList.add('active');
      if (tab.dataset.tab === 'resto') {
        if (formResto) formResto.classList.remove('hidden');
        if (formWorker) formWorker.classList.add('hidden');
      } else {
        if (formResto) formResto.classList.add('hidden');
        if (formWorker) formWorker.classList.remove('hidden');
      }
    });
  });

  // Mini tariff simulator
  const simOut = document.getElementById('simOut');
  const simPoste = document.getElementById('simPoste');
  const simZone = document.getElementById('simZone');
  const simUrg = document.getElementById('simUrg');
  function updateSim() {
    let base = 12;
    if (simPoste && simPoste.value === 'chef') base += 5;
    else if (simPoste && simPoste.value === 'plongeur') base -= 1;
    if (simZone) {
      if (simZone.value === 'big') base += 1;
      else if (simZone.value === 'we') base += 2;
    }
    if (simUrg && simUrg.value === 'yes') base += 2;
    if (simOut) simOut.textContent = base.toFixed(2) + ' € / h';
  }
  [simPoste, simZone, simUrg].forEach(el => {
    if (el) el.addEventListener('change', updateSim);
  });
  updateSim();

  // Generic form handler (demo)
  function handleForm(formId, okId, errId) {
    const form = document.getElementById(formId);
    const okEl = document.getElementById(okId);
    const errEl = document.getElementById(errId);
    if (!form) return;
    form.addEventListener('submit', (e) => {
      e.preventDefault();
      if (form.checkValidity()) {
        if (okEl) okEl.style.display = 'block';
        if (errEl) errEl.style.display = 'none';
        form.reset();
      } else {
        if (errEl) errEl.style.display = 'block';
        if (okEl) okEl.style.display = 'none';
      }
    });
  }
  handleForm('formResto', 'okR', 'errR');
  handleForm('formWorker', 'okW', 'errW');
  handleForm('pubForm', 'pubOk', 'pubErr');
  handleForm('candForm', 'candOk', 'candErr');

  // Chat box send message
  const chatInput = document.getElementById('chatInput');
  const chatSend = document.getElementById('chatSend');
  const chatBox = document.getElementById('chatBox');
  if (chatSend && chatInput && chatBox) {
    chatSend.addEventListener('click', () => {
      const msg = chatInput.value.trim();
      if (msg) {
        const div = document.createElement('div');
        div.className = 'kv';
        div.innerHTML = `<span>👤 Moi</span><span>${msg}</span>`;
        chatBox.appendChild(div);
        chatInput.value = '';
      }
    });
  }

  // Register service worker
  if ('serviceWorker' in navigator) {
    navigator.serviceWorker.register('/sw.min.js').catch(() => {});
  }
});