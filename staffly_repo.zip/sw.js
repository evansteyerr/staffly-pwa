// Service Worker for Staffly PWA
const CACHE_NAME = 'staffly-cache-' + Date.now();
const PRECACHE_URLS = [
  '/index.min.html',
  '/manifest.webmanifest',
  '/icons-192.png',
  '/icons-512.png'
];

self.addEventListener('install', event => {
  event.waitUntil(
    caches.open(CACHE_NAME).then(cache => {
      return cache.addAll(PRECACHE_URLS);
    })
  );
  // Activate the new service worker immediately without waiting
  self.skipWaiting();
});

self.addEventListener('activate', event => {
  event.waitUntil(
    caches.keys().then(keys => {
      return Promise.all(
        keys.map(key => {
          if (key !== CACHE_NAME) {
            return caches.delete(key);
          }
        })
      );
    })
  );
  // Take control of uncontrolled clients
  self.clients.claim();
});

// Intercept fetch requests
self.addEventListener('fetch', event => {
  // For navigation requests, try network first and fallback to cache
  if (event.request.mode === 'navigate') {
    event.respondWith(
      fetch(event.request).catch(() => caches.match('/index.min.html'))
    );
    return;
  }
  // Otherwise, respond with cache or network
  event.respondWith(
    caches.match(event.request).then(response => {
      return response || fetch(event.request);
    })
  );
});