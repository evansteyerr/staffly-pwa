# Staffly PWA

**Staffly** est une application web de mise en relation entre restaurants et travailleurs de la restauration (extras, CDD, CDI). Elle permet de publier des missions, de filtrer et de postuler en un clic, d'échanger via messagerie et de gérer contrats et paie intégrés. Cette version est une Progressive Web App (PWA) statique prête à être déployée.

## Fonctionnalités principales

- Interface responsive (desktop / mobile) avec navigation et menu hamburger.
- Formulaires d'inscription pour restaurants et travailleurs.
- Publication de missions avec mini‑simulateur de tarif (démo).
- Messagerie intégrée, planning, favoris, litiges et sections d'information.
- PWA installable : manifest, icônes, service worker et mode hors‑ligne (fallback sur `index.min.html`).
- Menu latéral animé accessible via les trois tirets.
- Couleurs et styles adaptés aux thèmes sombre et clair.

## Structure du dépôt

| Fichier              | Rôle                                                         |
|----------------------|--------------------------------------------------------------|
| `index.html`        | Version lisible et commentée de la page d'accueil.           |
| `index.min.html`    | Version minifiée utilisée par défaut et pré‑cache en PWA.    |
| `sw.js`             | Service worker (lisible).                                     |
| `sw.min.js`         | Service worker minifié chargé par `index.min.html`.          |
| `manifest.webmanifest` | Manifest PWA avec icônes et couleurs.                      |
| `icons-192.png` / `icons-512.png` | Icônes de l'application.                       |
| `assets.json`       | Informations de build (timestamp, fichiers).                 |
| `_redirects`        | Redirection Netlify (SPA) pour toutes les routes → index.    |
| `netlify.toml`      | Configuration Netlify.                                       |
| `Dockerfile`        | Image Docker simple servant le dossier avec Nginx.           |
| `nginx.conf`        | Configuration Nginx retournant `index.min.html` en fallback.  |

## Lancer en local

1. Servez simplement le répertoire via un serveur HTTP (par exemple avec **Nginx**, **Apache** ou `python -m http.server`).
2. Ouvrez `http://localhost:8000/index.min.html` dans votre navigateur. Le service worker sera enregistré automatiquement.
3. Pour tester le mode hors‑ligne, rechargez après avoir coupé la connexion : la page s’affichera grâce au cache.

## Utiliser Docker

Vous pouvez construire et lancer l’image Docker fournie pour servir l’application :

```bash
docker build -t staffly-pwa .
docker run -p 8080:80 staffly-pwa
```

L’application sera disponible sur `http://localhost:8080`.

## Déployer sur Netlify

Ce dépôt contient un fichier `_redirects` et un `netlify.toml` configuré pour servir une Single Page Application. Uploadez l’ensemble du répertoire ou utilisez le workflow GitHub Actions `netlify.yml` (nécessite les secrets `NETLIFY_AUTH_TOKEN` et `NETLIFY_SITE_ID`).

## Déployer sur GitHub Pages

Une action GitHub (voir `.github/workflows/pages.yml`) est prête pour déployer automatiquement la branche `main` sur GitHub Pages. Activez GitHub Pages via les **Settings** du dépôt, puis poussez votre code.

## Build et automatisation

`index.min.html` est généré à partir de `index.html` et conserve la structure originale tout en retirant les sauts de ligne. `sw.min.js` est une version compacte de `sw.js` sans commentaires. Le fichier `assets.json` inclut un timestamp de build. Les workflows GitHub peuvent être étendus pour regénérer ces fichiers automatiquement.